# vue-nav-tab — rounded logo kit

The logo contains three tabs titled **v**, **n**, and **t**. All lettering matches the frame. The open border under **n** identifies the active tab. All corners and letter terminals are rounded.

## Pick the right file

| Use | File / folder |
| --- | --- |
| Website, README, slides | `svg/horizontal-slate.svg`, or `png/horizontal-slate-1024.png` |
| Logo without project name | `svg/logo-slate.svg`, or `png/logo-slate-1024.png` |
| Dark background | Any `-white` SVG/PNG; these have transparent backgrounds |
| Monochrome reproduction | Any `-black` SVG/PNG/PDF/EPS |
| Office apps, design tools | Transparent PNGs in `png/` |
| Printer or vector editor | Vector PDF or EPS in `print/` |
| Apps that require JPEG | `jpg/` — explicit white or slate background |
| Browser favicon | `web/favicon.svg` and `web/favicon.ico` |
| Apple / app / PWA icons | `web/apple-touch-icon.png`, `icon-192.png`, `icon-512.png`, `maskable-512.png` |
| Social avatar | `social/avatar-512.png` or `avatar-1024.png` |
| Social preview / presentation cover | `social/share-card-1600x900.png` |

`preview.png` shows the kit. PNG filenames give width in pixels; height preserves the logo's proportions. Logo PNG widths: 64, 128, 256, 512, 1024, 2048. Horizontal widths: 512, 1024, 2048. Stacked and wordmark widths: 512, 1024. The transparent area inside the logo is real transparency.

## Palette and backgrounds

- Slate: **#243746**, RGB **36 / 55 / 70**.
- Black: **#000000**. White: **#FFFFFF**.
- Approximate slate CMYK: **49 / 21 / 0 / 73**. These are mathematical values, not a press proof.
- Use slate or black on light backgrounds, white on dark backgrounds. Use a solid background behind the logo on busy photos.
- Colour PDF/EPS artwork is RGB. A printer should convert using the intended press/paper profile; no CMYK profile or Pantone match is claimed.

## Sizes and clear space

- Lettered symbol: **64 px wide minimum**; prefer 96 px and above.
- Horizontal logo: **240 px wide minimum**. Stacked: **160 px wide minimum**.
- Favicons: **16–48 px**, using the supplied simplified tab-only cut. It intentionally omits letters because v/n/t would be unreadable at this size. Use the full lettered logo at larger sizes.
- Clear space: at least one frame thickness around the visible logo, or **14 units per 320 units of symbol width**. More space is welcome.
- For print, start at 16 mm wide for the lettered logo and inspect a physical proof. Embroidery needs a vendor test and may require the small symbol.

## Web integration

Copy the contents of `web/` into your chosen public asset directory. Adapt paths in `head-snippet.html` relative to your HTML page. The manifest icon paths are relative to the manifest, so project subpaths work. `favicon.svg` switches from slate to white with the viewer's dark-mode preference. ICO and favicon PNGs have transparent backgrounds. App and social icons have a deliberate solid slate background.

The manifest is an icon template, not a complete PWA configuration. Merge it into an existing manifest rather than replacing unrelated settings.

## Artwork

The approved lettered symbol is preserved in all full-size exports. Horizontal and stacked layouts add a custom rounded path wordmark. SVG/PDF/EPS artwork contains paths, not live logo text; no font installation is required. Presentation labels use system fonts and are not part of the logo.

Scale proportionally. Keep all three letter titles the same colour. Preserve the open active-tab border. Do not add a folder shoulder, shadows, gradients or decorative strokes.

## Scope

Files are supplied for digital and general vector use. PDF/EPS are not PDF/X-certified, press-profiled or embroidery stitch files. Trademark clearance was not performed. This kit is stored outside the repository; no project files, dependencies or git state were changed.
